#import <Cocoa/Cocoa.h>
#import "dacallib.h"

@interface AppController : NSObject {
// Disc to scan
	IBOutlet NSTextField *sourceExplainText;
	IBOutlet NSPathControl *sourcePath;
	IBOutlet NSTextField *sourceLevelNum;
	IBOutlet NSTextField *sourceTitle;
	IBOutlet NSStepper *sourceLevelStepper;
	IBOutlet NSButton *sourceDontScan;
	IBOutlet NSButton *sourceEjectDisc;
	IBOutlet NSButton *sourceScanButton;
// Carousel
	IBOutlet NSTextField *carouselNum;
	IBOutlet NSStepper *carouselStepper;
	IBOutlet NSTextField *carouselLabel;
	IBOutlet NSTextField *carouselExplainText;
	IBOutlet NSButton *carouselResetButton;
	IBOutlet NSButton *carouselIDButton;
//Slot
	IBOutlet NSTextField *slotNum;
	IBOutlet NSStepper *slotStepper;
	IBOutlet NSButton *slotGotoButton;
	IBOutlet NSButton *slotCloseButton;
	IBOutlet NSTextField *slotLabel;

	IBOutlet NSButton *createButton;
	IBOutlet NSProgressIndicator *createProgress;
	
	IBOutlet NSWindow *appWindow;
	IBOutlet NSImageView *windowIcon;
	
	NSWorkspace *workSpace;
	NSMutableArray*	deviceList;

	DACALDeviceRef carouselCount;
}

// Disc to scan
- (IBAction) scanButtonClicked:(id)sender;
- (IBAction) ejectDiscButtonClicked:(id)sender;
- (IBAction) sourceButtonClicked:(id)sender;
- (IBAction) levelStepperClicked:(id)sender;
// Carousel
- (IBAction) carouselStepperClicked:(id)sender;
- (IBAction) resetButtonClicked:(id)sender;
- (IBAction) idButtonClicked:(id)sender;
// Slot
- (IBAction) slotStepperClicked:(id)sender;
- (IBAction) gotoSlotButtonClicked:(id)sender;
- (IBAction) closeButtonClicked:(id)sender;
- (IBAction) createButtonClicked:(id)sender;

- (void) updateExplainText:(NSPathControl *)pathControl withTextField:(NSTextField *)textField  withText:(NSString *)text;	
- (void) updateSourceUI:(Boolean)enable;
- (void) updateCarouselUI:(Boolean)enable ;

@end
